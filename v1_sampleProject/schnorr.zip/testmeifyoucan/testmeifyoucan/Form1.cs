﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Numerics;
using System.Security.Cryptography;

namespace testmeifyoucan
{
    public partial class Form1 : Form
    {
        // Các biến lưu trữ khóa công khai và khóa bí mật
        private BigInteger p, q, g, y, a;

        public Form1()
        {
            InitializeComponent();
        }

        private void GenerateKeyButton_Click(object sender, EventArgs e)
        {
            // Sinh khóa công khai và khóa bí mật
            p = GenerateLargePrime();
            q = GenerateFactorOf(p - 1);
            g = GenerateGenerator(p, q);
            a = RandomBigInteger(1, q - 1);
            y = ModExp(g, a, p);

            outputTextBox.Text = $"Tạo khóa hoàn tất:\n- p: {p}\n- q: {q}\n- g: {g}\n- y: {y}\n- a: {a}";
        }

        private void GenerateSignatureButton_Click(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                outputTextBox.Text = "Lỗi: Thông điệp không được để trống.";
                return;
            }

            BigInteger k = RandomBigInteger(1, q - 1);
            BigInteger r = ModExp(g, k, p);
            BigInteger e = HashToBigInteger(message + r);
            BigInteger s = (a * e + k) % q;

            outputTextBox.Text = $"Chữ ký:\n- s: {s}\n- e: {e}";
        }

        private void VerifySignatureButton_Click(string message, string signature)
        {
            if (string.IsNullOrEmpty(message) || string.IsNullOrEmpty(signature))
            {
                outputTextBox.Text = "Lỗi: Thông điệp và chữ ký không được để trống.";
                return;
            }

            var parts = signature.Split(',');
            if (parts.Length != 2 || !BigInteger.TryParse(parts[0], out BigInteger s) || !BigInteger.TryParse(parts[1], out BigInteger e))
            {
                outputTextBox.Text = "Lỗi: Chữ ký không hợp lệ.";
                return;
            }

            BigInteger yInverse = ModInverse(y, p);
            BigInteger v = (ModExp(g, s, p) * ModExp(yInverse, e, p)) % p;
            BigInteger ePrime = HashToBigInteger(message + v);

            if (ePrime == e)
            {
                outputTextBox.Text = "Kết quả: Chữ ký hợp lệ.";
            }
            else
            {
                outputTextBox.Text = "Kết quả: Chữ ký không hợp lệ.";
            }
        }

        private (BigInteger, BigInteger, BigInteger) ExtGcd(BigInteger x, BigInteger n)
        {
            if (n == 0) return (x, 1, 0);
            var (d, a, b) = ExtGcd(n, x % n);
            return (d, b, a - b * (x / n));
        }

        private BigInteger ModInverse(BigInteger x, BigInteger n)
        {
            var (d, a, _) = ExtGcd(x, n);
            if (d != 1) throw new Exception("Không tồn tại nghịch đảo");
            return (a % n + n) % n;
        }

        private BigInteger ModExp(BigInteger e, BigInteger x, BigInteger n)
        {
            BigInteger result = 1;
            e %= n;
            while (x > 0)
            {
                if ((x & 1) == 1) result = (result * e) % n;
                e = (e * e) % n;
                x >>= 1;
            }
            return result;
        }

        private BigInteger HashToBigInteger(string data)
        {
            using var sha256 = SHA256.Create();
            byte[] hash = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(data));
            return new BigInteger(hash, isUnsigned: true, isBigEndian: true);
        }

        private BigInteger GenerateLargePrime()
        {
            Random rnd = new Random();
            while (true)
            {
                BigInteger candidate = RandomBigInteger(BigInteger.One << 512, (BigInteger.One << 513) - 1);
                if (MillerRabinTest(candidate, 10)) return candidate;
            }
        }

        private BigInteger GenerateFactorOf(BigInteger n)
        {
            Random rnd = new Random();
            while (true)
            {
                BigInteger candidate = RandomBigInteger(2, n - 1);
                if (n % candidate == 0 && MillerRabinTest(candidate, 10)) return candidate;
            }
        }

        private BigInteger GenerateGenerator(BigInteger p, BigInteger q)
        {
            Random rnd = new Random();
            while (true)
            {
                BigInteger b = RandomBigInteger(2, p - 2);
                BigInteger g = ModExp(b, (p - 1) / q, p);
                if (g != 1) return g;
            }
        }

        private BigInteger RandomBigInteger(BigInteger min, BigInteger max)
        {
            RandomNumberGenerator rng = RandomNumberGenerator.Create();
            byte[] bytes = max.ToByteArray();
            BigInteger result;
            do
            {
                rng.GetBytes(bytes);
                result = new BigInteger(bytes, isUnsigned: true);
            } while (result < min || result > max);
            return result;
        }

        private bool MillerRabinTest(BigInteger p, int iterations)
        {
            if (p < 2) return false;
            if (p == 2 || p == 3) return true;
            if (p % 2 == 0) return false;

            BigInteger q = p - 1;
            int k = 0;
            while (q % 2 == 0)
            {
                q /= 2;
                k++;
            }

            Random rnd = new Random();
            for (int i = 0; i < iterations; i++)
            {
                BigInteger a = RandomBigInteger(2, p - 2);
                BigInteger x = ModExp(a, q, p);
                if (x == 1 || x == p - 1) continue;

                bool prime = false;
                for (int j = 1; j < k; j++)
                {
                    x = (x * x) % p;
                    if (x == p - 1)
                    {
                        prime = true;
                        break;
                    }
                }
                if (!prime) return false;
            }
            return true;
        }
    }
}
