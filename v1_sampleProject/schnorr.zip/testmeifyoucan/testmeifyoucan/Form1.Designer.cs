﻿namespace testmeifyoucan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 700);
            this.Text = "Minh họa Schnorr Signature Scheme";
            this.Font = new System.Drawing.Font("Arial", 10);

            // RichTextBox hiển thị kết quả
            System.Windows.Forms.Label outputLabel = new System.Windows.Forms.Label { Text = "Kết quả:", Location = new System.Drawing.Point(20, 480), AutoSize = true };
            this.outputTextBox = new System.Windows.Forms.RichTextBox { Location = new System.Drawing.Point(20, 510), Width = 940, Height = 140, ReadOnly = true };

            // Khởi tạo các panel
            InitializeKeyGenerationPanel();
            InitializeSignaturePanel();
            InitializeVerificationPanel();

            this.Controls.AddRange(new System.Windows.Forms.Control[] { keyGenerationPanel, signaturePanel, verificationPanel, outputLabel, outputTextBox });
        }

        private void InitializeKeyGenerationPanel()
        {
            this.keyGenerationPanel = new System.Windows.Forms.Panel
            {
                Location = new System.Drawing.Point(20, 20),
                Size = new System.Drawing.Size(300, 200),
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            System.Windows.Forms.Label titleLabel = new System.Windows.Forms.Label { Text = "Tạo khóa", Location = new System.Drawing.Point(10, 10), AutoSize = true, Font = new System.Drawing.Font(this.Font, System.Drawing.FontStyle.Bold) };
            System.Windows.Forms.Button generateKeyButton = new System.Windows.Forms.Button { Text = "Tạo khóa", Location = new System.Drawing.Point(10, 50), AutoSize = true };

            generateKeyButton.Click += GenerateKeyButton_Click;

            this.keyGenerationPanel.Controls.AddRange(new System.Windows.Forms.Control[] { titleLabel, generateKeyButton });
        }

        private void InitializeSignaturePanel()
        {
            this.signaturePanel = new System.Windows.Forms.Panel
            {
                Location = new System.Drawing.Point(340, 20),
                Size = new System.Drawing.Size(300, 200),
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            System.Windows.Forms.Label titleLabel = new System.Windows.Forms.Label { Text = "Tạo chữ ký", Location = new System.Drawing.Point(10, 10), AutoSize = true, Font = new System.Drawing.Font(this.Font, System.Drawing.FontStyle.Bold) };
            System.Windows.Forms.Label messageLabel = new System.Windows.Forms.Label { Text = "Thông điệp:", Location = new System.Drawing.Point(10, 50), AutoSize = true };
            System.Windows.Forms.TextBox messageTextBox = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(80, 45), Width = 200 };
            System.Windows.Forms.Button generateSignatureButton = new System.Windows.Forms.Button { Text = "Tạo chữ ký", Location = new System.Drawing.Point(10, 90), AutoSize = true };

            generateSignatureButton.Click += (sender, e) => GenerateSignatureButton_Click(messageTextBox.Text);

            this.signaturePanel.Controls.AddRange(new System.Windows.Forms.Control[] { titleLabel, messageLabel, messageTextBox, generateSignatureButton });
        }

        private void InitializeVerificationPanel()
        {
            this.verificationPanel = new System.Windows.Forms.Panel
            {
                Location = new System.Drawing.Point(660, 20),
                Size = new System.Drawing.Size(300, 200),
                BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
            };

            System.Windows.Forms.Label titleLabel = new System.Windows.Forms.Label { Text = "Xác minh chữ ký", Location = new System.Drawing.Point(10, 10), AutoSize = true, Font = new System.Drawing.Font(this.Font, System.Drawing.FontStyle.Bold) };
            System.Windows.Forms.Label messageLabel = new System.Windows.Forms.Label { Text = "Thông điệp:", Location = new System.Drawing.Point(10, 50), AutoSize = true };
            System.Windows.Forms.TextBox messageTextBox = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(80, 45), Width = 200 };
            System.Windows.Forms.Label signatureLabel = new System.Windows.Forms.Label { Text = "Chữ ký:", Location = new System.Drawing.Point(10, 90), AutoSize = true };
            System.Windows.Forms.TextBox signatureTextBox = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(80, 85), Width = 200 };
            System.Windows.Forms.Button verifySignatureButton = new System.Windows.Forms.Button { Text = "Xác minh", Location = new System.Drawing.Point(10, 130), AutoSize = true };

            verifySignatureButton.Click += (sender, e) => VerifySignatureButton_Click(messageTextBox.Text, signatureTextBox.Text);

            this.verificationPanel.Controls.AddRange(new System.Windows.Forms.Control[] { titleLabel, messageLabel, messageTextBox, signatureLabel, signatureTextBox, verifySignatureButton });
        }

        private System.Windows.Forms.Panel keyGenerationPanel;
        private System.Windows.Forms.Panel signaturePanel;
        private System.Windows.Forms.Panel verificationPanel;
        private System.Windows.Forms.RichTextBox outputTextBox;

        #endregion
    }
}
